import ball
import pygame


class Game:
	def __init__(self, width, height):
		self.width = width
		self.height = height

		self.balls = []
		
		
	def addball(self, x, y):
		if len(self.balls) >= 10:
			self.balls.pop(0)

		self.balls.append( ball.Ball(x, y, self.width, self.height) )

	def game_logic(self, keys, newkeys, buttons, newbuttons, mouse_position):
		x = mouse_position[0]
		y = mouse_position[1]

		if 1 in newbuttons:
			self.addball(x,y)

		for b in self.balls:
			for b2 in self.balls:
				if b!=b2:
					if b.contains(b2):
						self.balls.remove(b)
						self.balls.remove(b2)

		for b in self.balls:
			b.move()


	def paint(self, surface):
		for b in self.balls:
			b.paint(surface)
