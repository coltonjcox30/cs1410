import pygame

from sky import Sky
from sun import Sun
from mountain import Mountain
from cloud import Cloud
from bigbird import BigBird
from smallbird import SmallBird

class Picture:
    def __init__(self, width, height):
        self.mWidth = width
        self.mHeight = height
        self.mSky = Sky(width, height)
        self.mSun1 = Sun(275, 250, 125)
        self.mSun1.setColor(240, 70, 0)
        self.mMountain1 = Mountain(width, height)
        self.mCloud1 = Cloud(40, 130, 200, 100)
        self.mCloud2 = Cloud(350, 35, 125, 75)
        self.mCloud3 = Cloud(425,60,90,70)
        self.mCloud4 = Cloud(200,180,100,60)	
        self.mBigBird1 = BigBird(425, 100)
        self.mBigBird2 = BigBird(525, 150)
        self.mSmallBird1 = SmallBird(190, 150)
        self.mSmallBird2 = SmallBird(230, 175)
        self.mSmallBird3 = SmallBird(130, 200)
        return

    def draw(self, surface):
        self.mSky.draw(surface)
        self.mSun1.draw(surface)
        self.mMountain1.draw(surface)
        self.mCloud1.draw(surface)
        self.mCloud2.draw(surface)
        self.mCloud3.draw(surface)
        self.mCloud4.draw(surface)
        self.mBigBird1.draw(surface)
        self.mBigBird2.draw(surface)
        self.mSmallBird1.draw(surface)
        self.mSmallBird2.draw(surface)
        self.mSmallBird3.draw(surface)
        return
