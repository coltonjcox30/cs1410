import pygame

from text import Text

class Sun:

    def __init__(self, x, y, r):
        self.mX = x
        self.mY = y
        self.mRadius = r
        self.mColor = (255, 150, 3)
        self.mText = Text("Sun", x, y)
        return

    def setColor(self, r, g, b):
        self.mColor = (int(r), int(g), int(b))
        return
        
    def draw(self, surface):
        center = (self.mX, self.mY)
        pygame.draw.circle(surface, self.mColor, center, self.mRadius, 0)
        self.mText.draw(surface)
        return
